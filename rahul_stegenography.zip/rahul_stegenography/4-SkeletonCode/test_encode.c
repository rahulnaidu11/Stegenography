#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

int main(int argc, char **argv)
{
   int ret = check_operation_type(argv);
   if(ret == e_encode)
   {
       printf("Encode option selected\n");
       printf("\n");
       EncodeInfo encinfo;
      if( read_and_validate_encode_args(argv,&encinfo)==e_failure)
      {
	  printf("Pass valid arguents-> ./a.out beautiful.bmp secret.txt\n");
      }
      else
      {
	  printf("Successful arguments passed\n");
	  do_encoding(&encinfo);
	 
      }
   }

   else if(ret == e_decode)
   {
       printf("Decode option selected\n");
       printf("\n");
       DecodeInfo decinfo;
      if( read_and_validate_decode_args(argv,&decinfo)==e_failure)
      {
	  printf("Pass valid arguents-> ./a.out hd_beautiful.bmp\n");
      }
      else
      {
	  printf("Successful arguments passed\n");
	  printf("\n");
	  do_decoding(&decinfo);
      }
	
   }
   
   else
   { 
       printf("Error:Please pass valid arguments ./a.out -e or ./a.out -d\n");
   }


    return 0;
}
OperationType check_operation_type(char **argv)
{
    if(strcmp(argv[1],"-e") == 0)
	return e_encode;
    else if(strcmp(argv[1],"-d") == 0)
	return e_decode;
    else
	return e_unsupported;
}
	  
